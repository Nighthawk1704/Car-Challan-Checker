import { useEffect, useState } from 'react'
import Header from './components/Header.jsx'
import Hero from './components/Hero.jsx'
import Steps from './components/Steps.jsx'
import VehicleInput from './components/VehicleInput.jsx'
import ChallanList from './components/ChallanList.jsx'
import StatusHistory from './components/StatusHistory.jsx'
import EmptyState from './components/EmptyState.jsx'
import Footer from './components/Footer.jsx'
import Loader from './components/Loader.jsx'
import FAQ from './components/FAQ.jsx'
import { getGeo, searchChallans } from './utils/api.js'

export default function App() {
  const [vehicleNo, setVehicleNo] = useState('')
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [geo, setGeo] = useState(null)
  const [selectedChallan, setSelectedChallan] = useState(null)
  const [filter, setFilter] = useState('all')

  useEffect(() => {
    getGeo().then(setGeo).catch(() => {})
  }, [])

  const onSearch = async (plate) => {
    if (!plate) return
    setError('')
    setLoading(true)
    setSelectedChallan(null)
    try {
      const data = await searchChallans(plate)
      setResult(data)
      setVehicleNo(plate)
    } catch (e) {
      setError(e.message || 'Something went wrong')
      setResult({ vehicleNo: plate, challans: [] })
    } finally {
      setLoading(false)
    }
  }

  const challans = (result?.challans || []).filter(c => {
    if (filter === 'all') return true
    return (c.status || 'Unpaid').toLowerCase() === filter
  })

  return (
    <div className="app-shell">
      <Header geo={geo} />
      <Hero onSearch={onSearch} />
      <Steps />

      <main className="container">
        <section className="panel section-card">
          <VehicleInput onSearch={onSearch} loading={loading} />
        </section>

        {loading && (
          <section className="panel section-card"><Loader label="Checking challans..." /></section>
        )}

        {error && (
          <section className="panel section-card error">
            <strong>Oops!</strong> {error}
          </section>
        )}

        {!loading && result && (
          <section className="grid">
            <div className="panel section-card">
              <div className="list-header">
                <h2 className="section-title">Challans ({challans.length})</h2>
                <div className="filters">
                  {['all','paid','unpaid'].map(f => (
                    <button key={f} className={`chip ${filter===f?'active':''}`} onClick={()=>setFilter(f)}>
                      {f[0].toUpperCase()+f.slice(1)}
                    </button>
                  ))}
                </div>
              </div>
              <ChallanList
                vehicleNo={vehicleNo}
                challans={challans}
                onSelect={setSelectedChallan}
                onUpdate={() => setResult({ ...result })}
              />
            </div>

            <div className="panel section-card">
              {selectedChallan ? (
                <StatusHistory vehicleNo={vehicleNo} challan={selectedChallan} />
              ) : (
                <EmptyState title="Select a challan" subtitle="Click a challan to view its detailed status history." />
              )}
            </div>
          </section>
        )}

        {!loading && result && result.challans?.length === 0 && (
          <section className="panel section-card">
            <EmptyState title="No challans found" subtitle={`No challans for ${vehicleNo}. Drive safe!`} />
          </section>
        )}

        {!loading && !result && (
          <section className="panel section-card">
            <EmptyState title="Welcome" subtitle="Search by vehicle number to see challans and status history." />
          </section>
        )}

        <section className="panel section-card">
          <FAQ />
        </section>
      </main>

      <Footer />
    </div>
  )
}
