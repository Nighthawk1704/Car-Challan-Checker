import data from '../data/challans.json'

export async function getGeo() {
  try {
    const res = await fetch('https://ipapi.co/json/')
    if (!res.ok) throw new Error('Failed to fetch location')
    const j = await res.json()
    return { city: j.city || 'Unknown', region: j.region || j.region_code || '—' }
  } catch (_) {
    return null
  }
}

export async function searchChallans(vehicleNo) {
  await new Promise((r) => setTimeout(r, 500))
  const normalize = s => String(s).toUpperCase().replace(/\s+/g,'')
  const entry = data.find((v) => normalize(v.vehicleNo) === normalize(vehicleNo))
  if (!entry) return { vehicleNo, challans: [] }
  return { vehicleNo: entry.vehicleNo, challans: entry.challans }
}
