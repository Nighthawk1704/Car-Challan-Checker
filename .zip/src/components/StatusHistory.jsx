import { getHistoryFor } from '../utils/status.js'
import Badge from './ui/Badge.jsx'

function download(filename, text) {
  const a = document.createElement('a')
  a.href = URL.createObjectURL(new Blob([text], { type: 'text/plain' }))
  a.download = filename
  a.click()
  URL.revokeObjectURL(a.href)
}

export default function StatusHistory({ vehicleNo, challan }) {
  const history = getHistoryFor(vehicleNo, challan)

  function exportJSON(){
    const payload = { vehicleNo, challan, history }
    download(`${vehicleNo}_${challan.id}.json`, JSON.stringify(payload, null, 2))
  }
  function exportCSV(){
    const rows = [['Status','Timestamp','Note'], ...history.map(h=>[h.status, h.timestamp, h.note||''])]
    const csv = rows.map(r=>r.map(x=>`"${String(x).replace(/"/g,'""')}"`).join(',')).join('\n')
    download(`${vehicleNo}_${challan.id}.csv`, csv)
  }

  return (
    <div>
      <div className="row space">
        <h2 className="section-title">Status History</h2>
        <div className="actions">
          <button className="btn ghost" onClick={exportCSV}>Export CSV</button>
          <button className="btn" onClick={exportJSON}>Export JSON</button>
        </div>
      </div>
      <div className="card">
        <div className="row space">
          <div>
            <h3 className="item-title">{challan.type}</h3>
            <p className="muted">Challan ID: {challan.id} • ₹ {challan.amount}</p>
          </div>
          <Badge tone={history[0]?.status === 'Paid' ? 'success' : 'warning'}>
            {history[0]?.status || 'Unknown'}
          </Badge>
        </div>
        <div className="timeline">
          {history.map((h, i) => (
            <div key={i} className="timeline-item">
              <div className="dot" />
              <div className="content">
                <div className="row space">
                  <strong>{h.status}</strong>
                  <span className="muted">{new Date(h.timestamp).toLocaleString()}</span>
                </div>
                {h.note && <p className="muted">{h.note}</p>}
              </div>
            </div>
          ))}
          {history.length === 0 && (
            <p className="muted">No history available.</p>
          )}
        </div>
      </div>
    </div>
  )
}
