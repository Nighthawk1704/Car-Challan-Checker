import Badge from './ui/Badge.jsx'
import { toggleStatus, getCurrentStatusFor } from '../utils/status.js'

export default function ChallanList({ vehicleNo, challans, onSelect, onUpdate }) {
  function handleToggle(challan) {
    toggleStatus(vehicleNo, challan)
    onUpdate?.()
  }

  if (challans.length === 0) {
    return <p className="muted">No challans for this filter.</p>
  }

  return (
    <div>
      <div className="list">
        {challans.map((c) => {
          const currentStatus = getCurrentStatusFor(vehicleNo, c)
          return (
            <article key={c.id} className="card list-item" onClick={() => onSelect(c)} role="button" tabIndex={0}>
              <div className="row space">
                <div>
                  <h3 className="item-title">{c.type}</h3>
                  <p className="muted">{new Date(c.date).toDateString()}</p>
                </div>
                <div className="right">
                  <Badge tone={currentStatus === 'Paid' ? 'success' : 'warning'}>{currentStatus}</Badge>
                </div>
              </div>
              <div className="row">
                <div className="muted">Challan ID: {c.id} • {c.location || '-'}</div>
                <div className="amount">₹ {c.amount}</div>
              </div>
              <div className="row">
                <button type="button" className="btn ghost" onClick={(e) => { e.stopPropagation(); handleToggle(c) }}>
                  Mark as {currentStatus === 'Paid' ? 'Unpaid' : 'Paid'}
                </button>
              </div>
            </article>
          )
        })}
      </div>
    </div>
  )
}
