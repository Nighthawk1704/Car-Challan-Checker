import Logo from '../assets/Car_logo.jpg'; // import your JPG logo

export default function Header({ geo }) {
  return (
    <header className="header">
      <div className="container header-row">
        {/* Brand */}
        <div className="brand">
          <img src={Logo} alt="Car Challan Checker logo" className="logo-img" />
          <div className="brand-text">
            {/* Clickable brand title (go home) */}
            <a href="/" className="brand-title" aria-label="Car Challan Checker — Home">
              Car <span className="brand-title-em">Challan Checker</span>
            </a>
            <p className="brand-subtitle">
              Check & manage your <strong>e-Challans</strong> instantly
              
            </p>
          </div>
        </div>

        {/* Geo (from free API) */}
        <div className="geo">
          {geo ? (
            <span title="Detected via free IP API">
              📍 {geo.city}, {geo.region}
            </span>
          ) : (
            <span className="muted">Detecting location…</span>
          )}
        </div>
      </div>
    </header>
  );
}