export default function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <p className="muted">
          Built for the Anslation Frontend Internship assignment. Demo data only. Free API used: <a href="https://ipapi.co/" target="_blank" rel="noreferrer">ipapi</a>.
        </p>
      </div>
    </footer>
  )
}
